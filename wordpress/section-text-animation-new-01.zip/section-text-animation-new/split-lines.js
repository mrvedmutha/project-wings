function getVisualLines(selector) {
  const el = document.querySelector(selector);
  if (!el) return;

  const fullText = el.textContent.replace(/\s+/g, " ").trim();
  const words = fullText.split(" ");

  el.innerHTML = words
    .map((word) => `<span class="__word">${word}</span>`)
    .join(" ");

  const spans = el.querySelectorAll(".__word");
  const lines = [];
  let currentTop = null;
  let currentLine = [];

  spans.forEach((span) => {
    const top = span.offsetTop;
    if (currentTop === null || top === currentTop) {
      currentLine.push(span.textContent);
    } else {
      lines.push(currentLine.join(" "));
      currentLine = [span.textContent];
    }
    currentTop = top;
  });

  if (currentLine.length) lines.push(currentLine.join(" "));

  el.innerHTML = lines
    .map(
      (lineText) =>
        `<span class="line"><span class="line-inner">${lineText}</span></span>`,
    )
    .join("");

  return lines;
}

function animateLines(selector) {
  const el = document.querySelector(selector);
  const lineInners = el.querySelectorAll(".line-inner");

  gsap.registerPlugin(ScrollTrigger);
  gsap.set(selector, { opacity: 1 });
  gsap.set(lineInners, { yPercent: 150, skewY: 1.5 });

  const tween = gsap.to(lineInners, {
    yPercent: 0,
    skewY: 0,
    ease: "power4.out",
    stagger: 0.25,
    duration: 0.8,
    scrollTrigger: {
      trigger: selector,
      start: "top 80%",
      toggleActions: "play none none none",
    },
  });

  if (tween.scrollTrigger) {
    scrollTriggers.push(tween.scrollTrigger);
  }

  return tween;
}

let resizeTimer;
let scrollTriggers = [];

function init() {
  getVisualLines(".split");
  animateLines(".split");
}

window.addEventListener("resize", () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    scrollTriggers.forEach((st) => st.kill());
    scrollTriggers = [];
    getVisualLines(".split");
    animateLines(".split");
  }, 400);
});

document.fonts.ready.then(init);
